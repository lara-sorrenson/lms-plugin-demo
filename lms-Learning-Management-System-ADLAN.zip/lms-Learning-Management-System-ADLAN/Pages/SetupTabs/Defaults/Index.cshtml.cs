using ClassLibrary1;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMSWebApp3.Pages.SetupTabs.Defaults
{
    public class IndexModel : PageModel
    {
        //CRUD
        private readonly DatabaseOperations _dbOps;
        public List<SetupInfo> results { get; set; }


        public IndexModel(DbConnect context) //Dependency Injection of DBConnect (DB Context) into controller constructor. _dbOps needs a context object to work off of. 
        {
            _dbOps = new DatabaseOperations(context);
        }

        public void OnGet() //When HTTP GET requests are tiggered
        {
            //SecMod table data is prepared to display on rendering the index page
            results = _dbOps.GetAllSetupInfos();
        }
    }
}
