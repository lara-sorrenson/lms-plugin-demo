using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LMSWebApp3.Pages.CourseCreate
{
    public class CreateFormModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
