﻿using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace LMSWebApp3.Pages.Shared
{
        public class IndexModel
        {
            public string ContentToShow { get; set; }

            public void OnGet(string content)
            {
                // Set the ContentToShow property based on the query parameter
                ContentToShow = content;
            }
            public string GetSetupContent()
            {
                return "Test text displayed!";
            }
        }
}
