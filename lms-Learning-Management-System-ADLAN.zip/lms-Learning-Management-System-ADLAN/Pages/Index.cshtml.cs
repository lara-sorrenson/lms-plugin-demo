using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace LMSWebApp3.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        [BindProperty]
        public string Input { get; set; }

        // Property to control which content to display
        [BindProperty(SupportsGet = true)] // SupportsGet for getting value from query parameters
        public string ContentToShow { get; set; } = "Setup"; // Default to "input" content
        //TODO: Matt, what's this for? - Eli

        public void OnGet()
        {
            // Additional logic can be added here if needed
        }

        public void OnPost()
        {
            // Additional logic can be added here if needed
        }
    }
}