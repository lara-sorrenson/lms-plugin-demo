/// This is a Model for the questions for different courses
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity


namespace ClassLibrary1
{
    [Table("lms_Questions")]
    public class Questions
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Question is Required !")]
        public string Question { get; set; }
        [Required(ErrorMessage = "Course ID is Required !")]
        public string CourseID { get; set; }
    }
}