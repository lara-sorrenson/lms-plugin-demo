/// Model for quiz which shows the title of the quiz and that the quiz is of which course
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity

namespace ClassLibrary1
{
    [Table("lms_Quiz")]
    public class Quiz
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Title is Required !")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Course ID is Required !")]
        public string CourseID { get; set; }
    }
}