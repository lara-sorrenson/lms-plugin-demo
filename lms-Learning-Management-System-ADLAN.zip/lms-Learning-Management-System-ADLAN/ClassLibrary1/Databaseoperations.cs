using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClassLibrary1
{
    public class DatabaseOperations
    {
        private readonly DbConnect _db;
        public DatabaseOperations(DbConnect db)
        {
            _db = db;
        }

        /// <param name="std"></param>
        public void StudentSignUp(Student std)
        {
            _db.Student.Add(std);
            _db.SaveChanges();
        }

        /// <param name="inst"></param>
        public void InstructorSignUp(Instructor inst)
        {
            _db.Instructor.Add(inst);
            _db.SaveChanges();
        }

        /// the function that gets the student's record from database when his/her profile is opened
        public Student SearchAndReturnStudent(int p)
        {
                return _db.Student.Find(p);
        }

        /// this function gets the instructor's record from the database when his/her profile in opened
        public Instructor SearchAndReturnInstructor(int p)
        { 
                return _db.Instructor.Find(p);
        }

        public List<Student> GetAllStudents()
        {
            return _db.Student.ToList();
        }

        public List<SecMod> GetAllSecMods() 
        {
            return _db.SecMod.ToList();
        }

        public List<Course> GetAllCourses()
        {
            return _db.Course.ToList();
        }

        public List<SetupInfo> GetAllSetupInfos() //Grabbing lms/olm sub-modules only
        {
            var lmsSetupInfos = _db.SetupInfo.Where(s => s.Module == "olm").ToList();
            if (!lmsSetupInfos.Any())
            {
                throw new Exception("No 'olm' entries found");
            }
            return lmsSetupInfos;
        }

        public List<SecUser> GetAllSecUsers()
        {
            return _db.SecUser.ToList();
        }
    }
}