/// This is a Model for module setup defaults 
/// TODO: Clarify propsed interaction between entity and defaults tab with PO - Eli 
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity


namespace ClassLibrary1
{
	[Table("glb_Setup")]
	public class SetupInfo
	{
		[Key]
		public long SetupID { get; set; }
		[Required(ErrorMessage = "Setup ID is Required !")]
		public string Module { get; set; }
		[Required(ErrorMessage = "Module prefix is Required !")]
		public string AttributeKey { get; set; }
		[Required(ErrorMessage = "Attribute Key is Required !")]
		public string AttributeValue { get; set; }
        //[Required(ErrorMessage = "Attribute Key is Required !")]
        // TODO: When's there's time, find out why the line above causes a CS1519 Error - Eli
    }
}