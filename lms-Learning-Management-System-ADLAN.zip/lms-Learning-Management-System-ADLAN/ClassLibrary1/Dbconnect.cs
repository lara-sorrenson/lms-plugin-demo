/// This is used for database creation
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace ClassLibrary1
{
    public class DbConnect : DbContext
    {
        public DbConnect(DbContextOptions<DbConnect> options) : base(options)
        {

        }

        /// All tables that are going to be included in the database
        public DbSet<Student> Student { get; set; }
        public DbSet<Instructor> Instructor { get; set; }
        public DbSet<Course> Course { get; set; }
        public DbSet<InstructorCourseAssignment> InstructorCourseAssignment { get; set; }
        public DbSet<StudentCourseAssignment> StudentCourseAssignment { get; set; }
        public DbSet<Quiz> Quiz { get; set; }
        public DbSet<Questions> Questions { get; set; }
        public DbSet<Options> Options { get; set; }
        public DbSet<Result> Result { get; set; }
        public DbSet<QuizQuestions> QuizQuestions { get; set; }
        public DbSet<SecMod> SecMod { get; set; }
        public DbSet<SecUser> SecUser { get; set; }
        public DbSet<SetupInfo> SetupInfo { get; set; }
    }
}