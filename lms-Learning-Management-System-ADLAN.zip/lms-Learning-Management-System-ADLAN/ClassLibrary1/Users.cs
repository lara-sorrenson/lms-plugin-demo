﻿/// This is a model for the Global Users table
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity

namespace ClassLibrary1
{
    [Table("glb_Users")]
    public class Users
    {
        [Key]
        [Required]
        public string MemberID { get; set; }
        [Required] //TODO: must include for not-null fields - Eli
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
        public int UserPoints { get; set; }
        public DateOnly? PostDate { get; set; }
        // TODO: test if using DateOnly, throws errors -Eli
    }
}
