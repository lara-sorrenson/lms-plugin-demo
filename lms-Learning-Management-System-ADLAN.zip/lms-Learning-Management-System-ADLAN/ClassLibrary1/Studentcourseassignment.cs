/// This model is used to store student's courses in which they are registered
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity

namespace ClassLibrary1
{
    [Table("lms_StudentCourseAssignment")]
    public class StudentCourseAssignment
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Instructor ID is Required")]
        public int StudentID { get; set; }
        [Required(ErrorMessage = "Course ID is Required")]
        public string CourseID { get; set; }
    }
}