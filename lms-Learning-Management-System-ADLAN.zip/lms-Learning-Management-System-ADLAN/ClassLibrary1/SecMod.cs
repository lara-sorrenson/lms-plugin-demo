﻿/// This is a model for the Module Security table
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity

namespace ClassLibrary1
{
    [Table("glb_SecMod")] //Actual table name in local Cobble DB
    public class SecMod
    {
        [Key]
        public long SecModID { get; set; }
        public string Module { get; set; }
        public string ModuleCode { get; set; }
        public string Description { get; set; }
        public int SecurityLevel { get; set; }

        //Navigation property?
        public ICollection<SecUser> SecUsers { get; set; }
    }
}
