﻿/// This is a model for the User Security* table
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Eventing.Reader; // grab this for each entity

namespace ClassLibrary1
{
    [Table("glb_SecUser")]
    public class SecUser
    {
        [Key]
        public long SecUserID { get; set; }
        public string MemberID { get; set; } //TODO: Find which table this FK originates from - Eli 
        //SecMod Foreign key property?
        [ForeignKey("SecMod")]
        public long SecModID { get; set; }
        // SecMod Navigation property
        public SecMod SecMod { get; set; }
        public int SecurityLevel { get; set; }
    }
}
