using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity


namespace ClassLibrary1
{
    [Table("lms_Course")]
    public class Course
    {
        [Key]
        public int ID { get; set; }
        public string CourseID { get; set; }
        public string CourseTitle { get; set; }
    }
}