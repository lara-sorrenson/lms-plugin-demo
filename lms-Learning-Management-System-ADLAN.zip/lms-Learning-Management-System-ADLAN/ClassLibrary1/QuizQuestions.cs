/// This model is used to store the different questions of every quiz
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity


namespace ClassLibrary1
{
    [Table("lms_QuizQuestions")]
    public class QuizQuestions
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Question ID is Required !")]
        public int QuestionID { get; set; }
        [Required(ErrorMessage = "Quiz ID is Required !")]
        public int QuizID { get; set; }
    }
}