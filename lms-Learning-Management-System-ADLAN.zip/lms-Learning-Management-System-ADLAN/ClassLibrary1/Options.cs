/// Model for storing different options in the questions of courses
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity


namespace ClassLibrary1
{
    [Table("lms_Options")]
    public class Options
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Option is Required !")]
        public string Option { get; set; }
        [Required(ErrorMessage = "Status is Required !")]
        public string Status { get; set; }
        [Required(ErrorMessage = "Question ID is Required !")]
        public int QuestionID { get; set; }
    }
}