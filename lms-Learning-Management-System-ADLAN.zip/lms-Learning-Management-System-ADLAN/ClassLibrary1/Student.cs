/// This is a model for students
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema; // grab this for each entity

namespace ClassLibrary1
{
    [Table("lms_Student")] //Actual table name in LMS schema. Make sure you include the import statement that's on line 7
    public class Student
    {
        [Key]
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string password { get; set; }
        public string RePassword { get; set; }
    }
}