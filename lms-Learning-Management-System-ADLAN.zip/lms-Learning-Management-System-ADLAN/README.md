# lms-Pending-Solutions
Pending-Solutions - Learning Management Systems


# How to Initialise the LMS plugin Through Kubernetes.
1. First Ensure Minikube is downloaded onto your system. `https://minikube.sigs.k8s.io/docs/start/`
2. Then Navigate to the directory where the plugin is located in. cd path/to... (this is all done through cmd or powershell)
3. Set the docker context to be default `docker context use default`
4. Run Minikub `minikube start`
5. Ensure minikube is working by `minikube status` it should show
`type: Control Plane`
`host: Running`
`kubelet: Running`
`apiserver: Running`
`kubeconfig: Configured`
7. After this set the docker enviroment by `minikube docker-env` then do `@FOR /f "tokens=*" %i IN ('minikube docker-env --shell cmd') DO @%i`
8. Build the Docker Image by: `docker build -t lms-plugin:latest .`
9. Apply the yaml file which should be in the same directory as the dockerfile. This can be applied by `kubectl apply -f deployment.yaml`
10. Check if everything has been added in and it is operational. This can be checked in 3 ways. The First is to check weather the pods are active
This can be done by `kubectl apply -f deployment.yaml`. You should see everything is running and there are no errors such as ImgPullBack
The Second is by `kubectl get deployments` and third is through `kubectl get services`. If all of these are ready and operational the final step is to run the service
11. To set the connection string variable run `kubectl set env deployment/lms-deployment ConnectionStrings__DbConnect="Server=(local);Database=Cobble;Integrated Security=true;TrustServerCertificate=true;"`
12. Run `kubectl get services` which will show all available services. then access minikube service through `minikube service lms-service`
13. Once ran it should give URL links to open the plugin or it should automatically open up the browser. 
14. If you need to mannually input the url use the second url that is given to you underneath the header `Starting tunnel for service lms-service`.


if your on Powershell do the following:
Do all steps until step 7. Then replace the code with `minikube -p minikube docker-env | Invoke-Expression`
Then continue with the rest



if any issues restart minikube by
`minikube stop`
`minikube delete`
`minikube start`

check dashboard
`minikube dashboard`
then status
`minikube status`
If dashboard says theres nothing thats good. then check status. if all good then continue from step 7
