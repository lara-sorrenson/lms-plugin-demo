﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LMSWebApp3.Migrations
{
    /// <inheritdoc />
    public partial class AddedRemainingModels : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_StudentCourseAssignment",
                table: "StudentCourseAssignment");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Result",
                table: "Result");

            migrationBuilder.DropPrimaryKey(
                name: "PK_QuizQuestions",
                table: "QuizQuestions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Quiz",
                table: "Quiz");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Questions",
                table: "Questions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Options",
                table: "Options");

            migrationBuilder.DropPrimaryKey(
                name: "PK_InstructorCourseAssignment",
                table: "InstructorCourseAssignment");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Instructor",
                table: "Instructor");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Course",
                table: "Course");

            migrationBuilder.RenameTable(
                name: "StudentCourseAssignment",
                newName: "lms_StudentCourseAssignment");

            migrationBuilder.RenameTable(
                name: "Result",
                newName: "lms_Result");

            migrationBuilder.RenameTable(
                name: "QuizQuestions",
                newName: "lms_QuizQuestions");

            migrationBuilder.RenameTable(
                name: "Quiz",
                newName: "lms_Quiz");

            migrationBuilder.RenameTable(
                name: "Questions",
                newName: "lms_Questions");

            migrationBuilder.RenameTable(
                name: "Options",
                newName: "lms_Options");

            migrationBuilder.RenameTable(
                name: "InstructorCourseAssignment",
                newName: "lms_InstructorCourseAssignment");

            migrationBuilder.RenameTable(
                name: "Instructor",
                newName: "lms_Instructor");

            migrationBuilder.RenameTable(
                name: "Course",
                newName: "lms_Course");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_StudentCourseAssignment",
                table: "lms_StudentCourseAssignment",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_Result",
                table: "lms_Result",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_QuizQuestions",
                table: "lms_QuizQuestions",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_Quiz",
                table: "lms_Quiz",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_Questions",
                table: "lms_Questions",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_Options",
                table: "lms_Options",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_InstructorCourseAssignment",
                table: "lms_InstructorCourseAssignment",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_Instructor",
                table: "lms_Instructor",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_lms_Course",
                table: "lms_Course",
                column: "ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_StudentCourseAssignment",
                table: "lms_StudentCourseAssignment");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_Result",
                table: "lms_Result");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_QuizQuestions",
                table: "lms_QuizQuestions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_Quiz",
                table: "lms_Quiz");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_Questions",
                table: "lms_Questions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_Options",
                table: "lms_Options");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_InstructorCourseAssignment",
                table: "lms_InstructorCourseAssignment");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_Instructor",
                table: "lms_Instructor");

            migrationBuilder.DropPrimaryKey(
                name: "PK_lms_Course",
                table: "lms_Course");

            migrationBuilder.RenameTable(
                name: "lms_StudentCourseAssignment",
                newName: "StudentCourseAssignment");

            migrationBuilder.RenameTable(
                name: "lms_Result",
                newName: "Result");

            migrationBuilder.RenameTable(
                name: "lms_QuizQuestions",
                newName: "QuizQuestions");

            migrationBuilder.RenameTable(
                name: "lms_Quiz",
                newName: "Quiz");

            migrationBuilder.RenameTable(
                name: "lms_Questions",
                newName: "Questions");

            migrationBuilder.RenameTable(
                name: "lms_Options",
                newName: "Options");

            migrationBuilder.RenameTable(
                name: "lms_InstructorCourseAssignment",
                newName: "InstructorCourseAssignment");

            migrationBuilder.RenameTable(
                name: "lms_Instructor",
                newName: "Instructor");

            migrationBuilder.RenameTable(
                name: "lms_Course",
                newName: "Course");

            migrationBuilder.AddPrimaryKey(
                name: "PK_StudentCourseAssignment",
                table: "StudentCourseAssignment",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Result",
                table: "Result",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_QuizQuestions",
                table: "QuizQuestions",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Quiz",
                table: "Quiz",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Questions",
                table: "Questions",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Options",
                table: "Options",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_InstructorCourseAssignment",
                table: "InstructorCourseAssignment",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Instructor",
                table: "Instructor",
                column: "ID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Course",
                table: "Course",
                column: "ID");
        }
    }
}
